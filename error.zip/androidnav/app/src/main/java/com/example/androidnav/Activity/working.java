package com.example.androidnav.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class working extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_working);
    }
}
